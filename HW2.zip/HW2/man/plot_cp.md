# Documentation for plot_cp function

## Description

Documentation for plot_cp function

## Usage

```r
plot_cp(dat, est, iso_code, CI = "95")
```

## Arguments

* `dat`: tibble corresponding to contraceptive_use dataset, lists mCPR, key columns: iso, obs_mCPR, mar_status, year
* `est`: tibble corresponding to est dataset, lists mCPR, key columns: iso, year, L95, L80, U95, U80
* `iso_code`: corresponds to iso/country code to plot
* `CI`: corresponds to confidence interval to plot as a geom_smooth outline - values are either 80, 95, or NA

## Value

ggplot graph that displays selected observations for a chosen country

## Examples

```r
(dat, est, 4, CI = "95")
```

